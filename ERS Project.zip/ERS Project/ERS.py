from tkinter import *
from pandas import *

emp=DataFrame()
emp=read_excel("ers.xlsx")
emp.set_index("ID")
job=DataFrame()
job=read_excel("jobvac.xlsx")
job.set_index("ID")
idno=emp.shape[0]

def updFile(): #For Updating changes,using pandas after profile Update/Selecting for Job
    writer=ExcelWriter("ers.xlsx")
    emp.to_excel(writer,index=None)
    writer.save()
    
def upd_File(): #For Updating changes,using pandas after Filtering Candidates for Job Selection
    writer=ExcelWriter("jobvac.xlsx")
    job.to_excel(writer,index=None)
    writer.save()
   
def ids(): #For list of all IDs
    return list(emp.loc[:,"ID"])

def DOB(): #For list of all DOBs
    return list(emp.loc[:,"DOB"])

def names(): #For list of all Names
    return list(emp.loc[:,"Name"])

def status(): #For list of all Status
    return list(emp.loc[:,"Status"])

def qual(): #For list of all Qualifications
    return list(emp.loc[:,"Qualification"])

def gender(): #For list of all Genders
    return list(emp.loc[:,"Gender"])

def con(): #For list of all Contacts
    return list(emp.loc[:,"Contact"])

def jobs(): #For list of all Job Post
    return list(job.loc[:,"Job Post"])

emp_id=ids()
emp_dob=DOB()
emp_name=names()
emp_stat=status()
emp_qual=qual()
emp_gender=gender()
emp_con=con()
jobs=jobs()


def newJob(): #Function for Application of New Job
    l1.destroy()
    l2.destroy()
    e1.destroy()
    e2.destroy()
    b1.destroy()
    ba.destroy()
    name=StringVar()
    dob=StringVar()
    age=StringVar()
    qual=StringVar()
    gender=StringVar()
    con=StringVar()
    _l1=Label(window,text="Please fill your details (* fields are mandatory) :")
    _l1.grid(row=0,column=0,columnspan=3)
    _l2=Label(window,text="Full Name* : ")
    _l2.grid(row=1,column=0)
    _e1=Entry(window,textvariable=name,width=25)
    _e1.grid(row=1,column=2,columnspan=2)
    _l3=Label(window,text="Date Of Birth* : ")
    _l3.grid(row=2,column=0)
    _e2=Entry(window,textvariable=dob,width=25)
    _e2.grid(row=2,column=2,columnspan=2)
    _l4=Label(window,text="Gender : ")
    _l4.grid(row=3,column=0)
    _e3=Entry(window,textvariable=gender,width=25)
    _e3.grid(row=3,column=2,columnspan=2)
    _l5=Label(window,text="Age : ")
    _l5.grid(row=4,column=0)
    _e4=Entry(window,textvariable=age,width=25)
    _e4.grid(row=4,column=2,columnspan=2)
    _l6=Label(window,text="Qualification* : ")
    _l6.grid(row=5,column=0)
    _e5=Entry(window,textvariable=qual,width=25)
    _e5.grid(row=5,column=2,columnspan=2)
    _l7=Label(window,text="Contact* : ")
    _l7.grid(row=6,column=0)
    _e6=Entry(window,textvariable=con,width=25)
    _e6.grid(row=6,column=2,columnspan=2)
    def jobSubmit(): 
        newName=name.get()
        newDOB=dob.get()
        newAge=age.get()
        newQual=qual.get()
        newGen=gender.get()
        newCon=con.get()
        newId=idno+1
        emp_t=emp.T
        emp_t[newId-1]=[newId,newName,newDOB,newAge,newQual,newGen,newCon,"Pending"]
        emp2=emp_t.T
        if(emp2.loc[idno,"Name"] and emp2.loc[idno,"DOB"] and 
           emp2.loc[idno,"Qualification"] and emp2.loc[idno,"Contact"] is not ""): 
            #To check if all Mandatory fields are fulfilled
            writer=ExcelWriter("ers.xlsx")
            emp2.to_excel(writer,index=None)
            writer.save()
            _l1.destroy()
            _l2.destroy()
            _l3.destroy()
            _l4.destroy()
            _l5.destroy()
            _l6.destroy()
            _l7.destroy()
            _e1.destroy()
            _e2.destroy()
            _e3.destroy()
            _e4.destroy()
            _e5.destroy()
            _e6.destroy()
            _b1.destroy()
            _lz=Label(window,text="Describe about yourself (100-150 words):")
            _lz.grid(row=0,column=0,columnspan=10)
            _s1=Scrollbar(window,width=16)
            _s1.grid(row=4,column=10)
            _t1=Text(window,height=7,width=50,bd=3)
            _t1.grid(row=1,column=0,rowspan=7)
            _s1.configure(command=_t1.yview)
            _ly=Label(window,text="Experience :")
            _ly.grid(row=10,column=0)
            _s2=Scrollbar(window,width=16)
            _s2.grid(row=14,column=10)
            _t2=Text(window,height=7,width=50,bd=3)
            _t2.grid(row=11,column=0,rowspan=7)
            _lx=Label(window,text="Certifications & Projects :")
            _lx.grid(row=20,column=0)
            _s3=Scrollbar(window,width=16)
            _s3.grid(row=24,column=10)
            _t3=Text(window,height=7,width=50,bd=3)
            _t3.grid(row=21,column=0,rowspan=7)
            _lw=Label(window,text="Technical Strengths :")
            _lw.grid(row=30,column=0)
            _s4=Scrollbar(window,width=16)
            _s4.grid(row=34,column=10)
            _t4=Text(window,height=7,width=50,bd=3)
            _t4.grid(row=33,column=0,rowspan=7)
            def subCV():
               abt=_t1.get("1.0","end-1c") #To get what is typed in textbox field
               exp=_t2.get("1.0","end-1c")
               c_p=_t3.get("1.0","end-1c")
               tech=_t4.get("1.0","end-1c")
               _lz.destroy()
               _ly.destroy()
               _lx.destroy()
               _lw.destroy()
               _lz.destroy()
               _t1.destroy()
               _t2.destroy()
               _t3.destroy()
               _t4.destroy()
               _s1.destroy()
               _s2.destroy()
               _s3.destroy()
               _s4.destroy()
               _bs.destroy()
               file=open("CV.txt","a")
               file.write("Name: "+emp2.loc[idno,"Name"]+"\n")
               file.write("ID: "+str(emp2.loc[idno,"ID"])+"\n")
               file.write("About: "+ abt+"\n")
               file.write("Experiences: "+exp+"\n")
               file.write("Certifications & Projects: "+c_p+"\n")
               file.write("Technical Skills: "+tech+"\n"+"\n"+"\n")
               file.close()
               _li=Listbox(window,width=50)
               _li.grid(row=0,column=0)
               _li.insert(END,"Your profile has been successfully recorded. Your ID is "+str(newId)+".")
               _li.insert(END,"Please login and check for your approval status")
            _bs=Button(window,text="Submit",command=subCV,width=12,bd=3)
            _bs.grid(row=43,column=0)          
        else: #If mandotory fields are not filled
            _l1.destroy()
            _l2.destroy()
            _l3.destroy()
            _l4.destroy()
            _l5.destroy()
            _l6.destroy()
            _l7.destroy()
            _e1.destroy()
            _e2.destroy()
            _e3.destroy()
            _e4.destroy()
            _e5.destroy()
            _e6.destroy()
            _b1.destroy()
            _lz=Label(window,text="Please fill all the mandatory details correctly. ")
            _ly=Label(window,text="Close and Try again!")
            _lz.grid(row=0,column=0)
            _ly.grid(row=1,column=0)
    _b1=Button(window,text="Submit",command=jobSubmit,width=21,bd=3)
    _b1.grid(row=7,column=2)
    
#Start of Functions of Admin Module
    
def chCV(): #To check CV by opening CV backend file using os module
    import os
    os.startfile("CV.txt")

def filCan(): #To Select/Reject Candidates and Appoint post if Selected
    l3=Listbox(window,height=10,width=45)
    l3.grid(row=5,column=2,columnspan=10,rowspan=15)
    l3.insert(END,"")
    l3.insert(END,"Name: ")
    l3.insert(END,"")
    selN=StringVar()
    selN.set(emp_name[0])
    o1=OptionMenu(window,selN,*emp_name)
    o1.grid(row=5,column=3)
    def cs(): #To check Status of Selected Person from OptionMenu(DropDown)
        sI=emp_name.index(str(selN.get()))
        l3.insert(END,"Status: ")
        l3.insert(END,"")
        selS=StringVar()
        selS.set(emp_stat[sI])
        st=["Selected","Rejected"]
        o2=OptionMenu(window,selS,*st)
        def setStat():
            emp.loc[sI,"Status"]=selS.get()
            updFile()
            if(selS.get()=="Selected"):
                selP=StringVar()
                selP.set(jobs[0])
                o3=OptionMenu(window,selP,*jobs)
                o3.grid(row=7,column=3)
                def app(): #To appoint and also update Backend if Selected
                    jI=jobs.index(str(selP.get()))
                    job.loc[jI,"Status"]="Selected"
                    job.loc[jI,"Name"]=str(selN.get())
                    job.loc[jI,"ID"]=(int(sI)+1)
                    upd_File()
                    emp.loc[sI,"Status"]="Selected"
                    updFile()
                    l3=Listbox(window,height=10,width=45)
                    l3.grid(row=5,column=2,columnspan=10,rowspan=15)
                    l3.insert(END,"Candidate Filtered")
                b_2=Button(window,text="Appoint",command=app)
                b_2.grid(row=8,column=3)
            else:
                emp.loc[sI,"Status"]="Rejected"
                updFile()
                l3=Listbox(window,height=10,width=45)
                l3.grid(row=5,column=2,columnspan=10,rowspan=15)
                l3.insert(END,"Candidate Filtered")
        b_1=Button(window,text="Confirm",command=setStat)
        b_1.grid(row=6,column=4)
        o2.grid(row=6,column=3)
    bs=Button(window,text="Check Status",command=cs)
    bs.grid(row=5,column=4)
    
    
def viewFeed(): #To view Feedback Or Query by opening Backend files using OS module
    l_a=Listbox(window,height=10,width=45)
    l_a.grid(row=5,column=2,columnspan=10,rowspan=15)
    def viewF(): #Opens Feedback Backend file
        import os
        os.startfile("Feedback.txt")
    def viewQ(): #Opens Query Backend file
        import  os
        os.startfile("Query.txt")
        
    b_a=Button(window,text="Feedback",command=viewF,width=15)
    b_a.grid(row=5,column=3)
    b_b=Button(window,text="Query",command=viewQ,width=15)
    b_b.grid(row=6,column=3)


def login(): #If user clicks on Login Button after Filling ID and DOb
    userId=e1.get("1.0","end-1c") #To get ID entered by user at Login
    dob=e2.get("1.0","end-1c") #To get DOB entered by user at Login
    if(userId.isdigit()==True): #To check if user enterd int type ID, if yes convert entered ID to string
        id=int(userId) #(by default entry widget takes strings, thats why we're converting so that we can fetch ID from backend)

#Start of Candidate Module Functions
    def viewVac(): #Shows Status of Vacancies
        l3=Listbox(window,height=10,width=45)
        l3.grid(row=5,column=2,columnspan=9,rowspan=15)
        for i in range(job.shape[0]):
            l3.insert(END,(job.loc[i,["Job Post","Status"]][0]+" - "+job.loc[i,
                           ["Job Post","Status"]][1]))
    
    def sendFeed(): #Sends Feedback

        def retFeed(): #To update in Backend file after submit
            feed=t1.get("1.0","end-1c")
            file=open("Feedback.txt","a")
            file.write("Name: "+emp.loc[id-1,"Name"]+"\n")
            file.write("ID: "+str(emp.loc[id-1,"ID"])+"\n")
            file.write("Feedback: "+"\n"+feed+"\n"+"\n")
            file.close()
            ty=Text(window,width=30,height=6,bd=3)
            ty.grid(row=5,column=2,rowspan=5,columnspan=5)
            ty.insert(END,"Feedback received. Thanks!")
        l3=Listbox(window,width=45)
        l3.grid(row=5,column=1,columnspan=10,rowspan=15)
        l3.insert(0,"\n Give your feedback below : ")
        sb=Scrollbar(window,width=17)
        sb.grid(row=5,column=7,rowspan=4)
        t1=Text(window,width=30,height=6,bd=3)
        t1.grid(row=5,column=2,rowspan=5,columnspan=5)
        sb.configure(command=t1.yview)
        bs=Button(window,text="Submit",command=retFeed)
        bs.grid(row=8,column=2)


    def sendQuery(): #To send Query

        def retFeed(): #To update in Backend file after submit
            query=t1.get("1.0","end-1c")
            file=open("Query.txt","a")
            file.write("Name: "+emp.loc[id-1,"Name"]+"\n")
            file.write("ID: "+str(emp.loc[id-1,"ID"])+"\n")
            file.write("Query: "+"\n"+query+"\n"+"\n")
            file.close()
            tx=Text(window,width=30,height=6,bd=3)
            tx.grid(row=5,column=2,rowspan=5,columnspan=5)
            tx.insert(END,"Please check your SMS for     responses.")
        l3=Listbox(window,width=45)
        l3.grid(row=5,column=1,columnspan=10,rowspan=15)
        l3.insert(0,"\n Ask your Queries below : ")
        sb=Scrollbar(window,width=17)
        sb.grid(row=5,column=7,rowspan=4)
        t1=Text(window,width=30,height=6,bd=3)
        t1.grid(row=5,column=2,rowspan=5,columnspan=5)
        sb.configure(command=t1.yview)
        bs=Button(window,text="Submit",command=retFeed)
        bs.grid(row=8,column=2)


    def updPro(): #To Update Profile Details
        l3=Listbox(window,width=45)
        l3.grid(row=5,column=2,columnspan=10,rowspan=15)
        l1=Label(window,text="Name")
        l1.grid(row=5,column=2)
        newName=StringVar()
        e3=Entry(window,textvariable=newName,bd=3)
        e3.grid(row=5,column=3)
        e3.insert(END,emp_name[id-1])
        l2=Label(window,text="DOB")
        l2.grid(row=6,column=2)
        newDOB=StringVar()
        e4=Entry(window,textvariable=newDOB,bd=3)
        e4.grid(row=6,column=3)
        e4.insert(END,str(emp_dob[id-1]))
        l3=Label(window,text="Gender")
        l3.grid(row=7,column=2)
        newGender=StringVar()
        e5=Entry(window,textvariable=newGender,bd=3)
        e5.grid(row=7,column=3)
        e5.insert(END,str(emp_gender[id-1]))
        l4=Label(window,text="Contact")
        l4.grid(row=8,column=2)
        newCon=StringVar()
        e6=Entry(window,textvariable=newCon,bd=3)
        e6.grid(row=8,column=3)
        e6.insert(END,str(emp_con[id-1]))
        def sendUpd(): #To update changes in backend after submitting
            emp.loc[id-1,"Name"]=newName.get()
            emp.loc[id-1,"DOB"]=newDOB.get()
            emp.loc[id-1,"Gender"]=newGender.get()
            emp.loc[id-1,"Contact"]=newCon.get()
            updFile()
            lz=Listbox(window,width=45)
            lz.grid(row=5,column=2,columnspan=10,rowspan=15)
            lz.insert(END,"Profile Updated. Changes will be reflected when")
            lz.insert(END,"you login next time")
        bs=Button(window,text="✓",command=sendUpd,width=2)
        bs.grid(row=8,column=6)
 
 
    if(userId.isdigit()==False): #If user enters alphabets in login ID, it executes "Login Unsuccessful" Label Widget, line 440
        l4.grid(row=3,column=3)    

    elif (id==111 and dob=="111"): #If userId and Dob is 111, admin module is opened
        l4.destroy()
        l8=Label(window,text=": "+str(id))
        l5=Label(window,text=": "+dob)
        l8.grid(row=1,column=2)
        l5.grid(row=2,column=2)
        e1.destroy()
        e2.destroy()
        b1.destroy()
        ba.destroy()
        b2=Button(window,text="View CVs",command=chCV,width=20,height=2)  
        b2.grid(row=5,column=0)
        b3=Button(window,text="Filter Candidates",command=filCan,width=20,height=2)  
        b3.grid(row=6,column=0)
        b4=Button(window,text="View Vacancies",command=viewVac,width=20,height=2)  
        b4.grid(row=7,column=0)
        b5=Button(window,text="View Feedback & Queries",command=viewFeed,width=20,height=2)  
        b5.grid(row=8,column=0)
        l3=Listbox(window,height=10,width=45)
        l3.grid(row=5,column=2,columnspan=10,rowspan=15)
        l3.insert(END,"Welcome Admin.")

    elif (id in emp_id and dob==emp.loc[id-1,"DOB"]): #If userID matches with DOB in backend, Candidate Module is Opened
        l4.destroy()
        l1.destroy()
        l2.destroy()
        l3=Listbox(window,height=10,width=45)
        l3.grid(row=5,column=2,columnspan=10,rowspan=15)
        l3.insert(END,"Welcome User.")
        l5=Label(window,text="User ID : "+str(id))
        l5.grid(row=1,column=0)
        l6=Label(window,text="Status: "+emp_stat[id-1])
        l6.grid(row=2,column=0)
        l7=Label(window,text="Name : "+emp_name[id-1])
        l7.grid(row=1,column=2)
        l8=Label(window,text="DOB : "+emp_dob[id-1])
        l8.grid(row=2,column=2)
        e1.destroy()
        e2.destroy()
        b1.destroy()
        ba.destroy()
        b2=Button(window,text="Update Profile Details",command=updPro,width=20,height=2)  
        b2.grid(row=5,column=0)
        b3=Button(window,text="View Vacancy Details",command=viewVac,width=20,height=2)  
        b3.grid(row=6,column=0)
        b4=Button(window,text="Give Feedback",command=sendFeed,width=20,height=2)  
        b4.grid(row=7,column=0)
        b5=Button(window,text="Send Queries",command=sendQuery,width=20,height=2)  
        b5.grid(row=8,column=0)    
    
    else: #If Login ID and DOB are left empty, Login Unsuccesful label in line 440 is executed/packed
        l4.grid(row=3,column=3)
    
    
window=Tk()
l4=Label(window,text="Login Unsuccesful")
window.title("Employee Recruitment System")
l1=Label(window,text="Admin ID/Application ID")
l1.grid(row=1,column=0)
l2=Label(window,text="Date of Birth")
l2.grid(row=2,column=0)
e1=Text(window,width=30,height=1)
e1.grid(row=1,column=2,columnspan=3)
e2=Text(window,width=30,height=1)
e2.grid(row=2,column=2,columnspan=3)
b1=Button(window,text="Login",command=login)
b1.grid(row=3,column=0,rowspan=2)
ba=Button(window,text="Apply for Job",command=newJob)
ba.grid(row=3,column=4)
window.mainloop()